#!/bin/bash

echo "Starting Java process with examples..."

java -Djava.ext.dirs=lib -jar transcoder-1.4-tests.jar